import java.util.*;

public class Dijkstra {
    public static Map<Cidade, Integer> calcularMenorCaminho(Mapa mapa, Cidade origem) {
        Map<Cidade, Integer> distancias = new HashMap<>();
        Map<Cidade, Cidade> antecessores = new HashMap<>();
        PriorityQueue<Cidade> queue = new PriorityQueue<>(Comparator.comparingInt(distancias::get));

        for (Cidade cidade : mapa.getCidades()) {
            if (cidade.equals(origem)) {
                distancias.put(cidade, 0);
            } else {
                distancias.put(cidade, Integer.MAX_VALUE);
            }
            queue.add(cidade);
        }

        while (!queue.isEmpty()) {
            Cidade cidadeAtual = queue.poll();

            for (Aresta aresta : mapa.getAdjacencias(cidadeAtual)) {
                Cidade destino = aresta.getDestino();
                int novaDistancia = distancias.get(cidadeAtual) + aresta.getDistancia();

                if (novaDistancia < distancias.get(destino)) {
                    queue.remove(destino);
                    distancias.put(destino, novaDistancia);
                    antecessores.put(destino, cidadeAtual);
                    queue.add(destino);
                }
            }
        }

        return distancias;
    }

    public static Map<Cidade, Cidade> getAntecessores(Mapa mapa, Cidade origem) {
        Map<Cidade, Integer> distancias = new HashMap<>();
        Map<Cidade, Cidade> antecessores = new HashMap<>();
        PriorityQueue<Cidade> queue = new PriorityQueue<>(Comparator.comparingInt(distancias::get));

        for (Cidade cidade : mapa.getCidades()) {
            if (cidade.equals(origem)) {
                distancias.put(cidade, 0);
            } else {
                distancias.put(cidade, Integer.MAX_VALUE);
            }
            queue.add(cidade);
        }

        while (!queue.isEmpty()) {
            Cidade cidadeAtual = queue.poll();

            for (Aresta aresta : mapa.getAdjacencias(cidadeAtual)) {
                Cidade destino = aresta.getDestino();
                int novaDistancia = distancias.get(cidadeAtual) + aresta.getDistancia();

                if (novaDistancia < distancias.get(destino)) {
                    queue.remove(destino);
                    distancias.put(destino, novaDistancia);
                    antecessores.put(destino, cidadeAtual);
                    queue.add(destino);
                }
            }
        }

        return antecessores;
    }

    public static List<Cidade> reconstruirCaminho(Cidade origem, Cidade destino, Map<Cidade, Cidade> antecessores) {
        List<Cidade> caminho = new ArrayList<>();
        for (Cidade at = destino; at != null; at = antecessores.get(at)) {
            caminho.add(at);
        }
        Collections.reverse(caminho);
        return caminho;
    }
}
