import java.util.*;

public class Mapa {
    private Map<Cidade, List<Aresta>> adjacencias = new HashMap<>();

    public void adicionarCidade(Cidade cidade) {
        adjacencias.putIfAbsent(cidade, new ArrayList<>());
    }

    public void adicionarAresta(Cidade origem, Cidade destino, int distancia) {
    	
    	   // Verifica se a cidade de origem já existe nas adjacências
        if (!adjacencias.containsKey(origem)) {
            adjacencias.put(origem, new ArrayList<>());
        }
        // Adiciona a nova aresta na lista de adjacências da cidade de origem
        adjacencias.get(origem).add(new Aresta(origem, destino, distancia));

        // Como é um grafo não-direcionado, adiciona a aresta também para o destino
        if (!adjacencias.containsKey(destino)) {
            adjacencias.put(destino, new ArrayList<>());
        }
        adjacencias.get(destino).add(new Aresta(destino, origem, distancia));
        	
        }


    public List<Cidade> getCidades() {
        return new ArrayList<>(adjacencias.keySet());
    }

    public void adicionarAresta(Cidade origem, Aresta aresta) {
        adjacencias.get(origem).add(aresta);
        
    }

    public void removerCidade(Cidade cidade) {
        adjacencias.remove(cidade);
        // Remover todas as arestas que conectam à cidade removida
        for (List<Aresta> lista : adjacencias.values()) {
            lista.removeIf(aresta -> aresta.getOrigem().equals(cidade) || aresta.getDestino().equals(cidade));
        }
    }

    public void removerAresta(Cidade origem, Cidade destino) {
        if (adjacencias.containsKey(origem)) {
            adjacencias.get(origem).removeIf(aresta -> aresta.getDestino().equals(destino));
        }
        if (adjacencias.containsKey(destino)) {
            adjacencias.get(destino).removeIf(aresta -> aresta.getDestino().equals(origem));
        }
    }

    public List<Aresta> getAdjacencias(Cidade cidade) {
        return adjacencias.get(cidade);
    }
}
